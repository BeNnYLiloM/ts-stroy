module.exports = [
    './gulp/tasks/watch',
    './gulp/tasks/clean',
    './gulp/tasks/serve',
    './gulp/tasks/svg',
    './gulp/tasks/img',
    './gulp/tasks/pug',
    './gulp/tasks/fonts',
    './gulp/tasks/scripts',
    './gulp/tasks/sass'
];
