$(document).ready(function () {

    svg4everybody({});

});